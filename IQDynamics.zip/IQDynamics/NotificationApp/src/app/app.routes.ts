import { Routes } from '@angular/router';
import { NotificationsComponent } from './components/notifications/notifications.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { UserGuard } from './guards/user.guard';

export const routes: Routes = [
    
    {
        path: "", component: LoginComponent
    },
    {
        path: "notification", component: NotificationsComponent
    },
    {path:'signup',component:SignupComponent,canActivate: [UserGuard]},
    {path:'login',component:LoginComponent},
];
