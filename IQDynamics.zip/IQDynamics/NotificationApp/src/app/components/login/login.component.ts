import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Login } from '../../models/login';
import { UserstoreService } from '../../services/userstore.service';
import { ResetPassword } from '../../models/ResetPassword';
import { CommonModule } from '@angular/common';


@Component({
selector: 'app-login',
standalone: true,
imports: [CommonModule, FormsModule,ReactiveFormsModule],
templateUrl: './login.component.html',
styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

credentials: Login = {UserName:'',Password:''}
type: string = "password";
isText: boolean = false;
eyeIcon: string = "fa-eye-slash";
loginForm!:FormGroup;
/*newPassword!: string;
confirmPassword!: string;


email!: string;*/
formVal!:FormGroup;

errorMessage!: string;
successMessage!: string;

constructor(private fb:FormBuilder,private auth:AuthService,private router:Router,private userStore:UserstoreService) { }

ngOnInit(): void {
  this.loginForm=this.fb.group({
    username:['',Validators.required],
    password:['',Validators.required]
  })
  this.formVal = this.fb.group({
    LoginId: ['', Validators.required],
    Password: ['', Validators.required],
    ConfirmPassword: ['', Validators.required],
  });
}

hideShowPass()

 {

this.isText = !this.isText;

 this.isText ? this.eyeIcon = "fa-eye" : this.eyeIcon = "fa-eye-slash";

this.isText ? this.type = "text" : this.type = "password";

}

onLogin(){
  if(this.loginForm.valid){
    console.log(this.loginForm.value)
    this.auth.login(this.credentials)
    .subscribe({
      next:(res)=>{
        //alert(res.message);
        console.log(res.message);
        this.loginForm.reset();
        this.auth.storeToken(res.token);
        const tokenPayload=this.auth.decodetoken();
        this.userStore.setFullNameForStore(tokenPayload.unique_name);
        this.userStore.setRoleForStore(tokenPayload.role);
        this.router.navigate(['notification']);
      },
      error:(err)=>{
        alert(err?.error.message)
      }
    })

  }
}

changePassword() {
  if (this.formVal.invalid) {
    return;
  }

  if (this.formVal.value.Password !== this.formVal.value.ConfirmPassword) {
    this.errorMessage = 'Passwords do not match';
    return;
  }

  const resetPasswordRequest: ResetPassword = {
    LoginId: this.formVal.value.LoginId,
    Password: this.formVal.value.Password,
    ConfirmPassword: this.formVal.value.ConfirmPassword
  };

  this.auth.resetPassword(this.formVal.value)
    .subscribe(
      (response) => {
        const { message } = response as { message: string }; // Parse the response as JSON object
        alert(message);
        // Reset form and any other necessary actions
        let ref = document.getElementById('closelogin');
   
        ref?.click();
        
        console.log(response);
        
        this.router.navigateByUrl('/',{skipLocationChange: true}).then(()=>
        
        {
        
         this.router.navigate(['/', 'login']);
        setTimeout(function(){
        
      alert("Updated Successfully");
        
        }, 100);
        
       }
       );
      }
     /* (error) => {
        console.log(error); // Log the error response to the console
        if (error.status === 404) {
          this.errorMessage = 'User not found';
        } else if (error.status === 400) {
          this.errorMessage = 'Invalid reset password request';
        } else {
          this.errorMessage = 'An error occurred';
        }
      }*/
    );
}

}



