import { Component, OnInit } from '@angular/core';
import { NotificationService } from '../../services/notification.service';
import { Notification } from '../../models/notification.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserstoreService } from '../../services/userstore.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications: Notification[] = [];
  notification: Notification = {
    notificationChannel: '',
    notificationHeading: '',
    notificationBody: '',
    notificationFooter: '',
    createdBy: '',
    repeatNotification: 'no',  
    useDocumentTemplate: 'default',  // Default value,
    documentTemplateID: 0
  };
  
  selectedNotification: Notification | null = null; // Store the currently selected notification
  successMessage: string | null = null;
  username: string | null = null;
  userMenuVisible: boolean = false;
  documentTemplates: { id: number, name: string }[] = [
    { id: 1, name: 'Template 1' },
    { id: 2, name: 'Template 2' },
    { id: 3, name: 'Template 3' },
    { id: 4, name: 'Template 4' }
  ];

  constructor(private notificationService: NotificationService,
    private userStore: UserstoreService,
              private router: Router
  ) { }

  ngOnInit(): void {
    this.loadNotifications();
    this.userStore.getFullnameFromStore().subscribe(username => {
      this.username = username
    });
    
  }

  loadNotifications() {
    this.notificationService.getNotifications().subscribe(data => {
      this.notifications = data;
    });
  }

  // Select a notification to edit
  selectNotification(notification: Notification) {
    this.selectedNotification = notification;
    this.notification = { ...notification }; // Populate the form with selected notification data
  }

  // Create a new notification
  createNewNotification() {
    this.selectedNotification = null; // Reset selected notification
    this.resetForm();
  }

  onTemplateChange(templateId: number) {
    // Set useDocumentTemplate to 'custom' when a template is selected
    this.notification.useDocumentTemplate = templateId ? 'custom' : 'default';
    this.notification.documentTemplateID = templateId;  // Assign the templateId
  }
  // Submit form to create or update a notification
  onSubmit() {
    // Subscribe to the observable returned by getFullNameFromStore
    this.userStore.getFullnameFromStore().subscribe(username => {
      // Set the createdBy and updatedBy fields using the username
      if (this.notification.notificationMessageID) {
        // Update existing notification
        this.notification.updatedBy = username;
        this.notificationService.updateNotification(this.notification).subscribe(() => {
          this.loadNotifications();
          this.resetForm();
          this.selectedNotification = null;
          this.showSuccessMessage('Notification updated successfully!');
        });
      } else {
        // Create a new notification
        this.notification.createdBy = username;
        this.notification.updatedBy = username;
        this.notificationService.createNotification(this.notification).subscribe(() => {
          this.loadNotifications();
          this.resetForm();
          this.selectedNotification = null;
          this.showSuccessMessage('Notification created successfully!');
        });
      }
    });
  }


  showSuccessMessage(message: string) {
    this.successMessage = message;
   alert(this.successMessage)
    // Hide the success message after 3 seconds
    setTimeout(() => {
      this.successMessage = null;
    }, 3000);
  }

 // Delete a notification
 deleteNotification(id: number, event: MouseEvent) {
    // Stop the click event from propagating to the parent list item
    event.stopPropagation();

    if (confirm('Are you sure you want to delete this notification?')) {
      this.notificationService.deleteNotification(id).subscribe(() => {
        this.loadNotifications();
        this.selectedNotification = null; // Reset after deletion
        this.resetForm();
      });
    }
  }

  onRepeatNotificationChange(event: any) {
    if (!event.target.checked) {
      this.notification.repeatNotification = 'no';  // Set to 'no' when unchecked
    }
    else{
      this.notification.repeatNotification = 'yes';
    }
  }
  
  // Reset the form to default state
  resetForm() {
    this.notification = {
      notificationChannel: '',
      notificationHeading: '',
      notificationBody: '',
      notificationFooter: '',
      createdBy: 'user',
      repeatNotification: 'no',  
      useDocumentTemplate: 'default',  // Default value,
      documentTemplateID: 0
    };
  }

  toggleUserMenu() {
    this.userStore.getFullnameFromStore().subscribe(username => {
      this.username = username
    });
    this.userMenuVisible = !this.userMenuVisible;
  }

  logout() {
 
    this.router.navigate(['login']);  // Navigate to the login page
  }
}
