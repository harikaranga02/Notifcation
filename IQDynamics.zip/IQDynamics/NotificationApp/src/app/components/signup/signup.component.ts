import { Component, OnInit } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, catchError, map } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule,ReactiveFormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  type: string = "password";

  isText: boolean = false;
  
  eyeIcon: string = "fa-eye-slash";
  
  signUpForm!: FormGroup;

  selectedRole:string="User";
  
  constructor( private fb : FormBuilder, private auth : AuthService, private router: Router) { }
  
  
  
  
  ngOnInit(): void {

    const currentDate = new Date();
    const formattedDate = this.formatDate(currentDate);
  
  
   this.signUpForm = this.fb.group({
  
   firstname : ['', [Validators.required,Validators.pattern(/^[a-zA-Z]*$/), this.minLengthValidator(1), this.maxLengthValidator(10) ]] ,     // Change to your desired minimum length
   // Change to your desired maximum length],
  
  lastname : ['', Validators.required],
  
  UserName: ['', [Validators.required],[this.checkUsernameExists]],
  
  password : ['', Validators.required],
  
  confirmPassword : ['', Validators.required],
  
  role : ['', Validators.required],
  
  createdDate: [formattedDate, Validators.required],
  updatedDate: [formattedDate, Validators.required]
  
   })
  
  
   }
  
  
   formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
  
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }
  
  
   hideShowPass()
  
  {
  
  this.isText = !this.isText;
  
  this.isText ? this.eyeIcon = "fa-eye" : this.eyeIcon = "fa-eye-slash";
  
  this.isText ? this.type = "text" : this.type = "password";
  
   }
  
   checkUsernameExists: AsyncValidatorFn = (control: AbstractControl): Observable<{ [key: string]: boolean } | null> => {
    const username = control.value;
  
    return this.auth.checkUsernameExist(username).pipe(
      map((exists) => (exists ? { usernameExists: true } : null)),
      catchError(async () => null) // Handle errors gracefully if necessary
    );
  };
  


 
  onSingup(){
  
  if(this.signUpForm.valid){
    const formattedCreatedDate = this.formatDate(this.signUpForm.value.createdDate);
    const formattedUpdatedDate = this.formatDate(this.signUpForm.value.updatedDate);

    const currentDate = new Date().toISOString();
      this.signUpForm.patchValue({
        createdDate: formattedCreatedDate,
        updatedDate: formattedUpdatedDate,
      });
  //perform logic for signup
  
  this.auth.signup(this.signUpForm.value)
  
  .subscribe({
  
  next:((res: { message: any; })=>{
  
  alert(res.message);
  
  this.signUpForm.reset();
  
  this.router.navigate(['']);
  
  })
  
  ,error:((err: { error: { message: any; }; })=>{
  
  alert(err?.error.message)
  })
  
  })
  
  
  
  
  console.log(this.signUpForm.value)
  
  }else{
  
  
  
  
  // ValidateForm.validateAllFormFirlds(this.signUpForm)
  
  //login for throwing error
  
  }
  
  }

  

// Custom validator to check if the input length is at least 'min' characters
 minLengthValidator(min: number): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    const value = control.value;
    if (value && value.length >= min) {
      return null;
    }
    return { minLength: true };
  };
}

// Custom validator to check if the input length is at most 'max' characters
 maxLengthValidator(max: number): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    const value = control.value;
    if (value && value.length <= max) {
      return null;
    }
    return { maxLength: true };
  };
}



}
