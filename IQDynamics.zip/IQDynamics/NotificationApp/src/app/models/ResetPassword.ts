export class ResetPassword{
    LoginId!:string;
    Password!:string;
    ConfirmPassword!:string;
}