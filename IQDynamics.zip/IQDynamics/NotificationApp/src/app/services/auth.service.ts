import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from "@angular/common/http";
import { Login } from '../models/login';
import { Router } from '@angular/router';
import{JwtHelperService} from '@auth0/angular-jwt'
import { Observable, map } from 'rxjs';
import { ResetPassword } from '../models/ResetPassword';


@Injectable({

 providedIn: 'root'

})

export class AuthService {

 private baseUrl: string = "https://localhost:7135/api/User/";
 private resetUrl:string="https://localhost:7135/api/User/";
 
private userPayload:any;

 constructor(private http : HttpClient,private router:Router) { 
   this.userPayload=this.decodetoken();
 }

signup(userObj:any){
return this.http.post<any>(`${this.baseUrl}register`, userObj)

}

login(loginObj:Login):Observable<any>{

 return this.http.post<any>(this.baseUrl +`login`, loginObj)

 }

 signout(){
    localStorage.clear();
    this.router.navigate([''])
 }

 storeToken(tokenValue:string){
localStorage.setItem('token',tokenValue)
 }

 getToken(){
    return localStorage.getItem('token')
 }

 isLoggedIn():boolean{
return !!localStorage.getItem('token')
 }

 decodetoken(){
   const jwtHelper=new JwtHelperService();
   const token=this.getToken()!;
   console.log(jwtHelper.decodeToken(token))
   return jwtHelper.decodeToken(token)
 }

 getFullNameFromToken(){
if(this.userPayload)
return this.userPayload.unique_name;
 }

 getRoleFromToken(){
if(this.userPayload)
return this.userPayload.role;
 }

 /*resetPassword(email: string, newPassword: string): Observable<any> {
  const resetPasswordRequest = { email, newPassword };
  return this.http.post<any>(this.resetUrl, resetPasswordRequest);
}*/
resetPassword(data:any){
  return this.http.post<any>(`${this.baseUrl}reset-password`,data)
    
 }

 checkUsernameExist(username: string): Observable<boolean> {

  const params = new HttpParams().set('UserName', username);
  return this.http.post<boolean>(`${this.baseUrl}userName`,null, { params });

 
 
}

}