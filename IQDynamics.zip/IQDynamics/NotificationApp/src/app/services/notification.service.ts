// src/app/notification.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Notification } from '../models/notification.model';

@Injectable({
    providedIn: 'root'
})
export class NotificationService {
    private apiUrl = 'https://localhost:7135/api/NotificationMessages'; // Your API URL

    constructor(private http: HttpClient) { }

    getNotifications(): Observable<Notification[]> {
        return this.http.get<Notification[]>(this.apiUrl);
    }

    getNotification(id: number): Observable<Notification> {
        return this.http.get<Notification>(`${this.apiUrl}/${id}`);
    }

    createNotification(notification: Notification): Observable<Notification> {
        return this.http.post<Notification>(this.apiUrl, notification);
    }

    updateNotification(notification: Notification): Observable<Notification> {
        return this.http.put<Notification>(`${this.apiUrl}/${notification.notificationMessageID}`, notification);
    }

    deleteNotification(id: number): Observable<void> {
        return this.http.delete<void>(`${this.apiUrl}/${id}`);
    }
}