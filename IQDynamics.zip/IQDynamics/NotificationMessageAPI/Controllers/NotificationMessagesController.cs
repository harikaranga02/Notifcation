﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NotificationMessageAPI.Data;
using NotificationMessageAPI.Models;

namespace NotificationMessageAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationMessagesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public NotificationMessagesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<NotificationMessage>>> GetNotificationMessages()
        {
            return await _context.NotificationMessages.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<NotificationMessage>> GetNotificationMessage(int id)
        {
            var notificationMessage = await _context.NotificationMessages.FindAsync(id);
            if (notificationMessage == null)
            {
                return NotFound();
            }
            return notificationMessage;
        }

        [HttpPost]
        public async Task<ActionResult<NotificationMessage>> PostNotificationMessage(CreateNotificationMessage notificationMessageCreateDto)
        {
            var notificationMessage = new NotificationMessage
            {
                NotificationChannel = notificationMessageCreateDto.NotificationChannel,
                NotificationHeading = notificationMessageCreateDto.NotificationHeading,
                NotificationBody = notificationMessageCreateDto.NotificationBody,
                NotificationFooter = notificationMessageCreateDto.NotificationFooter,
                NotificationSubject = notificationMessageCreateDto.NotificationSubject,
                RepeatEvery = notificationMessageCreateDto.RepeatEvery,
                NoOfTimesToRepeat = notificationMessageCreateDto.NoOfTimesToRepeat,
                CreatedBy = notificationMessageCreateDto.CreatedBy,
                CreatedDate = notificationMessageCreateDto.CreatedDate,
                RepeatNotification = notificationMessageCreateDto.RepeatNotification,
                UseDocumentTemplate = notificationMessageCreateDto.UseDocumentTemplate,
                DocumentTemplateID = notificationMessageCreateDto.DocumentTemplateID,
                UpdatedBy = notificationMessageCreateDto.CreatedBy
            };
            _context.NotificationMessages.Add(notificationMessage);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetNotificationMessage", new { id = notificationMessage.NotificationMessageID }, notificationMessage);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutNotificationMessage(int id, UpdateNotificationMessage notificationMessageUpdateDto)
        {
            if (id != notificationMessageUpdateDto.NotificationMessageID)
            {
                return BadRequest();
            }
            var notificationMessage = new NotificationMessage
            {
                NotificationChannel = notificationMessageUpdateDto.NotificationChannel,
                NotificationHeading = notificationMessageUpdateDto.NotificationHeading,
                NotificationBody = notificationMessageUpdateDto.NotificationBody,
                NotificationFooter = notificationMessageUpdateDto.NotificationFooter,
                NotificationSubject = notificationMessageUpdateDto.NotificationSubject,
                RepeatEvery = notificationMessageUpdateDto.RepeatEvery,
                NoOfTimesToRepeat = notificationMessageUpdateDto.NoOfTimesToRepeat,
                RepeatNotification = notificationMessageUpdateDto.RepeatNotification,
                UseDocumentTemplate = notificationMessageUpdateDto.UseDocumentTemplate,
                DocumentTemplateID = notificationMessageUpdateDto.DocumentTemplateID,
                UpdatedBy = notificationMessageUpdateDto.UpdatedBy,
                UpdatedDate = notificationMessageUpdateDto.UpdatedDate
            };
            _context.Entry(notificationMessage).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteNotificationMessage(int id)
        {
            var notificationMessage = await _context.NotificationMessages.FindAsync(id);
            if (notificationMessage == null)
            {
                return NotFound();
            }
            _context.NotificationMessages.Remove(notificationMessage);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
