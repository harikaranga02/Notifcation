﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.RegularExpressions;
using System.IdentityModel.Tokens.Jwt;
using System;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using HospitalManagement.Models;
using NotificationMessageAPI.Data;

namespace AuthenticationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext _PatientDbContext)
        {
            _context = _PatientDbContext;
        }

        [HttpPost("register")]
        public async Task<IActionResult> RegisterUser([FromBody] UserModel userObj)
        {
            if (userObj == null)
                return BadRequest();

            //Check UserName
            if (await CheckUserNameExistAsync(userObj.UserName))
                return BadRequest(new { Message = "UserName Already Exist!" });


            //Check Password strength
            var pass = CheckPasswordStrength(userObj.Password);
            if (!string.IsNullOrEmpty(pass))
                return BadRequest(new { Message = pass.ToString() });

            // Hash the password
            userObj.Password = EncrpytPassword(userObj.Password);

            await _context.userModels.AddAsync(userObj);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Message = "User Registered!"
            });
        }

        [HttpPost("login")]   // For Login
        public async Task<IActionResult> Login([FromBody] UserLogin userObj)
        {
            // If user is sending a blank object it will return bad request
            if (userObj == null)
                return BadRequest();

            // Fetch the user by loginId
            var user = await _context.userModels.FirstOrDefaultAsync(x => x.UserName == userObj.UserName);

            if (user == null)
                return NotFound(new { Message = "User Not Found!" });
           

            // Decrypt the stored password
            string decryptedStoredPassword = DecryptPassword(user.Password);

            // Compare the decrypted password with the raw password entered during login
            if (decryptedStoredPassword == userObj.Password)
            {
                var Token = CreateJwt(user);
                return Ok(new
                {
                    Token = Token,
                    Message = "Login Success!"
                });
            }
            else
            {
                return NotFound(new { Message = "Invalid Password!" });
            }
        }


        public static string EncrpytPassword(string password)
        {
            if(string.IsNullOrEmpty(password))
            {
                return null;
            }
            else
            {
                byte[] storePassword= Encoding.UTF8.GetBytes(password);
                string encrptedPassword=Convert.ToBase64String(storePassword);
                return encrptedPassword;
            }
        }

        public static string DecryptPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }
            else
            {
                byte[] encrptedPassword = Convert.FromBase64String(password);
                string decryptedPassword = Encoding.UTF8.GetString(encrptedPassword);
                return decryptedPassword;
            }
        }


        private async Task<bool> CheckUserNameExistAsync(string UserName)
        {
            return await _context.userModels.AnyAsync(x => x.UserName == UserName);
        }

      
        private string CheckPasswordStrength(string password)
        {
            StringBuilder str = new StringBuilder();

            if (password.Length < 8)
                 str.Append("Minimum password length should be 8" + '\n');
             if (!(Regex.IsMatch(password, "[a-z]") && Regex.IsMatch(password, "[A-Z]")
                 && Regex.IsMatch(password, "[0-9]")))
                 str.Append("Password should be Alphanumeric (Atleast 1 Uppercase, 1 Lowercase, 1 Number) " + '\n');
             if (!Regex.IsMatch(password, "[/,[,`,~,!,@,#,$,%,^,&,*,(,),_,|,+,\\,-,=,?,;,:']"))
                 str.Append("Password should contain special chars" + '\n');
           
            return str.ToString();
        }

        //Creating JWT Token
        private string CreateJwt(UserModel user)
        {
            //header
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("aVeryLongSecretKeyForJwtAuthThatIsAtLeast32Characters!");

            //payload
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}")
            });

            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = credentials
            };
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        
    }

    }


}
