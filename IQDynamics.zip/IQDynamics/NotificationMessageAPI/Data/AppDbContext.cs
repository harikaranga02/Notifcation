﻿namespace NotificationMessageAPI.Data
{
    using HospitalManagement.Models;
    using Microsoft.EntityFrameworkCore;
    using NotificationMessageAPI.Models;

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<NotificationMessage> NotificationMessages { get; set; }

        public DbSet<UserModel> userModels { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define primary keys
            modelBuilder.Entity<UserModel>().HasKey(u => u.Id);

            // Define table names and triggers
            modelBuilder.Entity<UserModel>().ToTable("tbl_user");
        }
    }
}
