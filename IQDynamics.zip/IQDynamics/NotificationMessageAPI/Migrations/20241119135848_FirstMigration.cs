﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NotificationMessageAPI.Migrations
{
    public partial class FirstMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "NotificationMessages",
                columns: table => new
                {
                    NotificationMessageID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NotificationChannel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NotificationHeading = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NotificationBody = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NotificationFooter = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NotificationSubject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RepeatEvery = table.Column<int>(type: "int", nullable: true),
                    NoOfTimesToRepeat = table.Column<int>(type: "int", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UpdatedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    RepeatNotification = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UseDocumentTemplate = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DocumentTemplateID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NotificationMessages", x => x.NotificationMessageID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "NotificationMessages");
        }
    }
}
